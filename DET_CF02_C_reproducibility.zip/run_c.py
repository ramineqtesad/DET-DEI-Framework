import numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pathlib import Path
import json,zipfile
P=Path('/mnt/data/det_cf02')
def run(a=2,b=1,c=1,rho=3,L=1.5,n=101,dt=.05,T=100):
 grid=np.linspace(-L,L,n);X,Z=np.meshgrid(grid,grid);x=X.copy();z=Z.copy(); h=dt
 def f(x,z):return a*x-b*x*x*x-c*z,rho*(x-z)
 for _ in range(round(T/h)):
  k1,l1=f(x,z);k2,l2=f(x+h*k1/2,z+h*l1/2);k3,l3=f(x+h*k2/2,z+h*l2/2);k4,l4=f(x+h*k3,z+h*l3)
  x+=h*(k1+2*k2+2*k3+k4)/6;z+=h*(l1+2*l2+2*l3+l4)/6
  if not np.isfinite(x).all():break
 if a>c: eq=np.sqrt((a-c)/b)
 else: eq=None
 cls=np.zeros(X.shape,dtype=np.int8)
 if eq is not None:
  cls[np.hypot(x-eq,z-eq)<1e-5]=1
  cls[np.hypot(x+eq,z+eq)<1e-5]=-1
 elif np.isfinite(x).all():cls[np.hypot(x,z)<1e-5]=2
 return X,Z,cls
rows=[];cache={}
def record(group,name,**kwargs):
 X,Z,cls=run(**kwargs);d=X<.8;nf=int(d.sum());nfr=int((d&(cls==1)).sum());un=int((cls==0).sum());out=dict(group=group,scenario=name,**{'a':kwargs.get('a',2),'b':kwargs.get('b',1),'c':kwargs.get('c',1),'rho':kwargs.get('rho',3),'L':kwargs.get('L',1.5),'n':kwargs.get('n',101)},N=int(X.size),N_plus=int((cls==1).sum()),N_minus=int((cls==-1).sum()),N_zero=int((cls==2).sum()),N_unresolved=un,N_degraded=nf,N_degraded_recoverable=nfr,P_FR=nfr/nf if nf else None)
 rows.append(out);cache[name]=(X,Z,cls)
record('baseline','baseline')
for c in [.5,.75,1,1.25,1.5]:record('c_sweep',f'c={c}',c=c)
for rho in [.5,1,2,3,5]:record('rho_sweep',f'rho={rho}',rho=rho)
for a in [1.5,2,2.5]:record('a_sweep',f'a={a}',a=a)
for b in [.5,1,1.5]:record('b_sweep',f'b={b}',b=b)
for L in [1,1.5,2]:record('domain',f'L={L}',L=L)
for n in [51,101,151]:record('resolution',f'n={n}',n=n)
for dt in [.1,.05,.025]:record('time_step',f'dt={dt}',dt=dt)
DF=pd.DataFrame(rows);DF.to_csv(P/'DET_CF02_C_scenarios.csv',index=False)
X,Z,cls=cache['baseline'];thresholds=[]
for t in [.2,.5,.8,1,1.2]:
 d=X<t;thresholds.append(dict(threshold=t,N_degraded=int(d.sum()),N_recoverable=int((d&(cls==1)).sum()),P_FR=float((d&(cls==1)).sum()/d.sum())))
pd.DataFrame(thresholds).to_csv(P/'DET_CF02_C_thresholds.csv',index=False)
# 2x2 summary figure
fig,axs=plt.subplots(2,2,figsize=(10.5,7.5));
for ax,group,key,xlabel in [(axs[0,0],'c_sweep','c','Memory coupling c'),(axs[0,1],'rho_sweep','rho','Memory adjustment rate rho'),(axs[1,0],'domain','L','Half-width of sampled domain'),(axs[1,1],'resolution','n','Grid points per axis')]:
 sub=DF[DF.group==group].sort_values(key);ax.plot(sub[key],sub.P_FR,'o-',color='black',lw=1.4);ax.axhline(DF.iloc[0].P_FR,ls=':',color='gray');ax.set(xlabel=xlabel,ylabel='P_FR',ylim=(0,1));ax.grid(alpha=.2)
fig.suptitle('DET-CF02-C | Robustness of degraded-but-recoverable fraction');fig.tight_layout();fig.savefig(P/'DET_CF02_C_robustness.png',dpi=210);plt.close(fig)
fig,ax=plt.subplots(figsize=(7.5,4.5)); tt=pd.DataFrame(thresholds);ax.plot(tt.threshold,tt.P_FR,'o-',color='black');ax.set(xlabel='Functional threshold x_C',ylabel='P_FR',ylim=(0,1),title='Threshold sensitivity | fixed baseline basin');ax.grid(alpha=.2);fig.tight_layout();fig.savefig(P/'DET_CF02_C_threshold.png',dpi=210);plt.close(fig)
summary={'baseline':rows[0],'thresholds':thresholds,'scenarios':len(rows),'max_unresolved':int(DF.N_unresolved.max()),'scenarios_with_unresolved':DF.loc[DF.N_unresolved>1,['scenario','N_unresolved']].to_dict('records')}
(P/'DET_CF02_C_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
with zipfile.ZipFile(P/'DET_CF02_C_reproducibility.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in ['run_c.py','DET_CF02_C_scenarios.csv','DET_CF02_C_thresholds.csv','DET_CF02_C_robustness.png','DET_CF02_C_threshold.png','DET_CF02_C_summary.json']:z.write(P/f,arcname=f)
print(DF[['group','scenario','N_plus','N_minus','N_unresolved','P_FR']].to_string(index=False));print('thresholds',thresholds)
