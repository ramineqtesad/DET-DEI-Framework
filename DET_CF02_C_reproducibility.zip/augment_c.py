import runpy,numpy as np,pandas as pd,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt,zipfile
from pathlib import Path
p=Path('/mnt/data/det_cf02')
# avoid rerun by calculate selected classifications from saved function script AST? runpy executes all, okay
m=runpy.run_path(str(p/'run_c.py')); base=m['cache']['baseline'][2]; records=[]
for name in ['c=0.5','c=0.75','c=1.25','c=1.5','rho=0.5','rho=1','rho=2','rho=5','a=1.5','a=2.5','b=0.5','b=1.5']:
 cls=m['cache'][name][2]; changed=int((cls!=base).sum()); records.append(dict(scenario=name,changed_points=changed,changed_percent=100*changed/base.size,baseline_positive=int((base==1).sum()),new_positive=int((cls==1).sum())))
df=pd.DataFrame(records);df.to_csv(p/'DET_CF02_C_basin_geometry_changes.csv',index=False)
fig,ax=plt.subplots(figsize=(8,4.8));ax.barh(df.scenario,df.changed_percent,color='0.35');ax.invert_yaxis();ax.set(xlabel='Grid points changing basin classification (%)',title='Basin geometry changes despite similar aggregate P_FR');fig.tight_layout();fig.savefig(p/'DET_CF02_C_geometry.png',dpi=200);plt.close(fig)
with zipfile.ZipFile(p/'DET_CF02_C_reproducibility.zip','a',zipfile.ZIP_DEFLATED) as z:
 for f in ['DET_CF02_C_basin_geometry_changes.csv','DET_CF02_C_geometry.png','augment_c.py']:z.write(p/f,arcname=f)
print(df.to_string(index=False))
