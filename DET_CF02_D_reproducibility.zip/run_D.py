import numpy as np,pandas as pd,matplotlib.pyplot as plt,json,zipfile
from scipy.integrate import solve_ivp
from pathlib import Path
P=Path('/mnt/data/det_cf02'); dt=.025; T=40.; grid=np.linspace(-1.5,1.5,51); X,Z=np.meshgrid(grid,grid); init=np.stack([X.ravel(),Z.ravel()],axis=1)
def rhs(y,F):
 x,z=y[:,0],y[:,1];return np.stack([2*x-x**3-z+F,3*(x-z)],axis=1)
def evolve(y,t0,t1,force):
 y=y.copy(); n=int(np.ceil((t1-t0)/dt));h=(t1-t0)/n
 for j in range(n):
  t=t0+j*h;k1=rhs(y,force(t));k2=rhs(y+h*k1/2,force(t+h/2));k3=rhs(y+h*k2/2,force(t+h/2));k4=rhs(y+h*k3,force(t+h));y+=h*(k1+2*k2+2*k3+k4)/6
 return y
def classify(y):
 dplus=np.linalg.norm(y-[1,1],axis=1);dminus=np.linalg.norm(y+ [1,1],axis=1)
 return np.where(dplus<1e-4,1,np.where(dminus<1e-4,-1,0))
base=classify(evolve(init,0,T,lambda t:0))
rows=[]; details=[]
# force negative pulses and ramps of equal integrated load
for kind in ['pulse','ramp']:
 for tau in [1.,3.,6.]:
  for A in [-.2,-.5,-1.]:
   if kind=='pulse': force=lambda t,A=A:A
   else: force=lambda t,A=A,tau=tau:2*A*t/tau
   end=evolve(init,0,tau,force)
   final=evolve(end,tau,tau+T,lambda t:0)
   cl=classify(final); switched=(base==1)&(cl==-1)
   # ignore initial separatrix and unresolved
   rows.append(dict(profile=kind,mean_force=A,duration=tau,integrated_force=A*tau,baseline_positive=int((base==1).sum()),switched_from_positive=int(switched.sum()),switch_pct_positive=100*switched.sum()/(base==1).sum(),unresolved=int((cl==0).sum()),final_positive=int((cl==1).sum())))
   details.append((kind,tau,A,cl))
df=pd.DataFrame(rows);df.to_csv(P/'DET_CF02_D_scenarios.csv',index=False)
# trajectory single initial + equilibrium
trajrows=[]
for kind in ['pulse','ramp']:
 for tau in [1.,3.,6.]:
  for A in [-.2,-.5,-1.]:
   def ff(t):return A if kind=='pulse' and t<tau else (2*A*t/tau if kind=='ramp' and t<tau else 0.)
   sol=solve_ivp(lambda t,y:[2*y[0]-y[0]**3-y[1]+ff(t),3*(y[0]-y[1])],(0,tau+40),[1.,1.],rtol=1e-10,atol=1e-12,max_step=.03,dense_output=True)
   post=sol.sol(tau+40)
   trajrows.append(dict(profile=kind,duration=tau,mean_force=A,integrated_force=A*tau,x_at_release=float(sol.sol(tau)[0]),z_at_release=float(sol.sol(tau)[1]),x_final=float(post[0]),z_final=float(post[1]),final_attractor='E+' if np.linalg.norm(post-[1,1])<1e-4 else ('E-' if np.linalg.norm(post+np.ones(2))<1e-4 else 'undetermined')))
pd.DataFrame(trajrows).to_csv(P/'DET_CF02_D_equilibrium_start.csv',index=False)
# independent verify RK4 grid sample against DOP853 (40 pts selected)
rng=np.random.default_rng(42); inds=rng.choice(np.flatnonzero(base==1),8,replace=False);checks=[]
for kind,tau,A in [('pulse',3.,-.5),('ramp',3.,-.5),('pulse',6.,-1.)]:
 v=[x for x in details if x[0]==kind and x[1]==tau and x[2]==A][0][3]
 for ix in inds:
  ff=lambda t: (A if kind=='pulse' else 2*A*t/tau) if t<tau else 0
  sol=solve_ivp(lambda t,y:[2*y[0]-y[0]**3-y[1]+ff(t),3*(y[0]-y[1])],(0,tau+T),init[ix],method='DOP853',rtol=1e-10,atol=1e-12,max_step=.15)
  cl=classify(sol.y[:,-1].reshape(1,2))[0];checks.append(dict(profile=kind,duration=tau,mean_force=A,index=int(ix),rk4=int(v[ix]),dop853=int(cl),agree=bool(v[ix]==cl)))
chk=pd.DataFrame(checks);chk.to_csv(P/'DET_CF02_D_solver_checks.csv',index=False)
plt.rcParams['font.family']='DejaVu Sans'
fig,axes=plt.subplots(1,2,figsize=(12,4.5))
for kind,ls in [('pulse','-'),('ramp','--')]:
 for tau in [1.,3.,6.]:
  ss=df[(df.profile==kind)&(df.duration==tau)]
  axes[0].plot(-ss.mean_force,ss.switch_pct_positive,marker='o',linestyle=ls,label=f'{kind}, duration={tau:g}')
axes[0].set(xlabel='Mean negative forcing magnitude',ylabel='Baseline E+ states switched to E- (%)',title='Grid-wide regime switching');axes[0].legend(fontsize=7);axes[0].grid(alpha=.2)
for kind,ls in [('pulse','-'),('ramp','--')]:
 ss=pd.read_csv(P/'DET_CF02_D_equilibrium_start.csv');ss=ss[(ss.profile==kind)&(ss.duration==3)]
 axes[1].plot(-ss.mean_force,ss.x_final,marker='o',linestyle=ls,label=f'{kind}, duration=3')
axes[1].set(xlabel='Mean negative forcing magnitude',ylabel='Final x from initial (1,1)',title='Single-state recovery');axes[1].legend();axes[1].grid(alpha=.2)
fig.tight_layout();fig.savefig(P/'DET_CF02_D_forcing.png',dpi=220);plt.close(fig)
summary={'total_scenarios':len(df),'grid_size':len(init),'baseline_positive':int((base==1).sum()),'baseline_negative':int((base==-1).sum()),'baseline_unresolved':int((base==0).sum()),'solver_checks':len(chk),'solver_disagreements':int((~chk.agree).sum())}
(P/'DET_CF02_D_summary.json').write_text(json.dumps(summary,indent=2))
with zipfile.ZipFile(P/'DET_CF02_D_reproducibility.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
 for nm in ['run_D.py','DET_CF02_D_scenarios.csv','DET_CF02_D_equilibrium_start.csv','DET_CF02_D_solver_checks.csv','DET_CF02_D_forcing.png','DET_CF02_D_summary.json']:z.write(P/nm,arcname=nm)
print(summary);print(df.to_string(index=False));print('\nEquilibrium start\n',pd.DataFrame(trajrows).to_string(index=False))
