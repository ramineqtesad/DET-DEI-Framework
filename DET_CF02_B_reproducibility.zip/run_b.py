import numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp
from scipy.linalg import eig
from pathlib import Path
import csv, json, zipfile
p=Path('/mnt/data/det_cf02'); n=101; grid=np.linspace(-1.5,1.5,n); X,Z=np.meshgrid(grid,grid); x=X.copy(); z=Z.copy()
def f(x,z):return 2*x-x**3-z,3*(x-z)
dt=.05; steps=2000
for i in range(steps):
 a,b=f(x,z);c,d=f(x+dt*a/2,z+dt*b/2);e,g=f(x+dt*c/2,z+dt*d/2);h,j=f(x+dt*e,z+dt*g)
 x+=dt*(a+2*c+2*e+h)/6;z+=dt*(b+2*d+2*g+j)/6
pos=np.hypot(x-1,z-1);neg=np.hypot(x+1,z+1);zero=np.hypot(x,z)
cls=np.full(X.shape,0,dtype=int);cls[(pos<1e-5)&(pos<neg)]=1;cls[(neg<1e-5)&(neg<pos)]=-1
# saddle exact initial remains saddle; non-converged near separatrix are unresolved
cls[(zero<1e-9)]=0
Npos=int((cls==1).sum());Nneg=int((cls==-1).sum());Nun=int((cls==0).sum());degraded=X<.8
Nf=int(degraded.sum());Nfr=int(((cls==1)&degraded).sum());Nfp=int(((cls==-1)&degraded).sum());Nfu=int(((cls==0)&degraded).sum())
# independent adaptive solver validation random deterministic sample, excluding unresolved
rng=np.random.default_rng(20261023); ids=rng.choice(np.flatnonzero(cls!=0),size=120,replace=False); disagreements=0
for k in ids:
 r,c=np.unravel_index(k,cls.shape); y0=[X[r,c],Z[r,c]]
 sol=solve_ivp(lambda t,y:f(*y),(0,100),y0,method='DOP853',rtol=1e-10,atol=1e-12)
 xx,zz=sol.y[:,-1]; label=1 if np.hypot(xx-1,zz-1)<1e-5 else (-1 if np.hypot(xx+1,zz+1)<1e-5 else 0)
 disagreements+=label!=cls[r,c]
# compute stable manifold via backward integration eigenvector stable at saddle
J=np.array([[2,-1],[3,-3.]]); vals,vec=eig(J); idx=np.argmin(vals.real); v=vec[:,idx].real;v/=np.linalg.norm(v)
branches=[]
for sign in (-1,1):
 s=solve_ivp(lambda t,y: -np.array(f(*y)),(0,30),sign*1e-7*v,method='DOP853',rtol=1e-11,atol=1e-13,max_step=.025,events=lambda t,y: max(abs(y[0]),abs(y[1]))-2)
 branches.append(s.y)
# make plot with transparent neutral colormap
from matplotlib.colors import ListedColormap,BoundaryNorm
fig,ax=plt.subplots(figsize=(8.4,7.1));cmap=ListedColormap(['#dddddd','#f5f5f5','#808080']);ax.pcolormesh(X,Z,cls,cmap=cmap,norm=BoundaryNorm([-1.5,-.5,.5,1.5],3),shading='nearest',rasterized=True)
for branch in branches:ax.plot(branch[0],branch[1],color='black',lw=1.6,label='Basin boundary' if branch is branches[0] else None)
ax.axvline(.8,color='black',linestyle='--',lw=1.6,label='Functional threshold x = 0.8');ax.plot([0,1,-1],[0,1,-1],marker='o',ls='none',color='black',ms=5)
ax.annotate('E+', (1,1),xytext=(1.08,1.04));ax.annotate('E−',(-1,-1),xytext=(-1.35,-.92));ax.annotate('E0',(0,0),xytext=(.08,-.16));ax.set(xlim=(-1.5,1.5),ylim=(-1.5,1.5),xlabel='Observed state x(0)',ylabel='Memory state z(0)',title='DET-CF02-B | Basins of attraction and functional threshold');ax.legend(loc='upper right',fontsize=9);fig.tight_layout();fig.savefig(p/'DET_CF02_B_basins.png',dpi=220);plt.close(fig)
with (p/'DET_CF02_B_grid.csv').open('w',newline='') as fh:
 w=csv.writer(fh);w.writerow(['x0','z0','x100','z100','basin_class','functional_degradation'])
 for vals in zip(X.ravel(),Z.ravel(),x.ravel(),z.ravel(),cls.ravel(),degraded.ravel()):w.writerow([float(v) for v in vals[:4]]+[int(vals[4]),int(vals[5])])
summary=dict(grid_n=n,points=n*n,dt=dt,t_end=100,positive=Npos,negative=Nneg,unresolved=Nun,degraded=Nf,degraded_recoverable=Nfr,degraded_negative=Nfp,degraded_unresolved=Nfu,pr=Npos/(n*n),pfr=Nfr/Nf,adaptive_validation_n=len(ids),adaptive_disagreements=int(disagreements),saddle_eigenvalues=[float(q.real) for q in vals] if False else [float(q.real) for q in np.linalg.eigvals(J)],threshold_x=.8)
(p/'DET_CF02_B_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
with zipfile.ZipFile(p/'DET_CF02_B_reproducibility.zip','w',zipfile.ZIP_DEFLATED) as zz:
 for name in ['run_b.py','DET_CF02_B_basins.png','DET_CF02_B_grid.csv','DET_CF02_B_summary.json']:zz.write(p/name,arcname=name)
print(summary)
